
public class NegativesNotAllowedException extends Exception {
	public NegativesNotAllowedException(String exception) {
		super(exception);
	}
}
